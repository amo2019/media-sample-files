export const FETCH_USER = 'fetch_user';
export const FETCH_SURVEYS = 'fetch_surveys';
